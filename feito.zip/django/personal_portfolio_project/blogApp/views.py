from django.shortcuts import render
from .models import Blog

# Create your views here.

def all_blog(request):
    blogs = Blog.objects.order_by('date')[:2]
    return render(request, 'blogApp/detail.html', {'blogs':blogs})

def detail(request, blog_id):
    blog = get_object_or_404(Blog, pk=blog_id)
    return render(request, 'blogApp/detail.html')