from django.shortcuts import render
from django.http import HttpResponse

# Create your views here. #Evidentemente el nombre variara entre cada proyecto, pero esta es la idea principal.
def home(request):
    return render(request, 'passwordApp/home.html')

def result(request):
    if request.method == 'GET':
        username = request.GET.get('username', '')
        city = request.GET.get('city', '')
        role = request.GET.get('role', '')
        sign = request.GET.get('sign', '')

        context = {
            'username': username,
            'city': city,
            'role': role,
            'sign': sign,
        }
        
        return render(request, 'passwordApp/result.html', context)